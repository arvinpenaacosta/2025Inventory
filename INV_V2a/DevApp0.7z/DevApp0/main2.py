import json
import sqlite3
import os
import uvicorn

from fastapi import FastAPI, Form, Request, HTTPException, Depends, status
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse 
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

from jose import jwt, JWTError
from datetime import datetime, timedelta
from auth.authentication import authenticate, authenticate_netmiko, authenticate_dummy
from auth.auth_sqlitedb import authenticate_user, authenticate_Xuser


# import datetime
from pydantic import BaseModel
from datetime import datetime
from dotenv import load_dotenv
from pprint import pprint
from tabulate import tabulate

from io import BytesIO
from typing import Optional


from typing import List


from models.dd_select import init_db, get_programs, get_items

from models.item_log_routes import router as item_log_router  # Import the router



SECRET_KEY = "your-secret-key"  # Replace with a strong secret key
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30  # Set token expiration as needed

# Database file path
DB_FILE = os.getenv("DB_FILE", "db/1DAassets.db")  # Default to 'db/entries.db' if not specified
# Header file path
PAGE_HEADER = os.getenv("PAGE_HEADER", "DevApp Inventory Logger - Version 0")  # Default to 'Page Footer' if not specified
# Footer file path
PAGE_FOOTER = os.getenv("PAGE_FOOTER", "2024 DevApps. All Rights Reserved.")  # Default to 'Page Footer' if not specified




app = FastAPI()
# Mount static files
app.mount("/statics", StaticFiles(directory="statics"), name="statics")
# Initialize templates
templates = Jinja2Templates(directory="templates")


##################################################################
# Run the database initialization
@app.on_event("startup")
def on_startup():
    
    init_db()

def format_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##########################   ITEM LOG ISSUANCE   ########################################
@app.get("/entryAPI/programs")
def get_programs_route():
    return get_programs()

@app.get("/entryAPI/items")
def get_items_route():
    return get_items()


class ItemLogSearchRequest(BaseModel):
    search_term: str  # The term to search across multiple fields

# item_log -> SEARCH RECORD from items-log
@app.post("/entryAPI/items-log-search", response_model=List[dict])
def search_items_log(request: ItemLogSearchRequest):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    search_query = f"""
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
        WHERE 
            p.program_name LIKE ? OR 
            i.item_name LIKE ? OR 
            il.quantity LIKE ? OR 
            il.location LIKE ? OR 
            il.reason LIKE ?
    """
    search_value = f"%{request.search_term}%"
    cursor.execute(search_query, (search_value, search_value, search_value, search_value, search_value))
    
    item_search = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return item_search

##########################   ITEM LOG ISSUANCE   #######################################
# Include the item log routes
app.include_router(item_log_router)


################## JSON WEB TOKEN for Authentication  ##################################

# Function to create JWT token
def create_access_token(data: dict, expires_delta: timedelta = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)):
    to_encode = data.copy()
    to_encode.update({"exp": datetime.utcnow() + expires_delta})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# Dependency to get current user from the token
async def get_current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated1")
    
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated2")
        
        password: str = payload.get("psub")
        if password is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token structure")

        # Return both values (you can return them as a tuple)
        return username, password

    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token3")

# Function to handle response after authentication
def handle_authenticated_response(username: str, password: str) -> RedirectResponse:
    access_token = create_access_token(data={"sub": username, "psub": password})
    response = RedirectResponse(url="/dashboard", status_code=303)
    response.set_cookie(key="access_token", value=access_token, httponly=True, max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60)
    return response

# Function to handle the error response
def handle_error_response(auth_result: str) -> RedirectResponse:
    error_message = "Can't connect to server to validate user." if auth_result == "Can't connect to server to validate user." else "Invalid username or password"
    return RedirectResponse(url=f"/?error={error_message}", status_code=303)


#######################################################################
# load Welcome Page - if Authenticated redirect to Dashboard
@app.get("/", response_class=HTMLResponse)
async def read_index(request: Request):
    error = request.query_params.get("error")
    token = request.cookies.get("access_token")
    if token:
        try:
            await get_current_user(request)
            return RedirectResponse(url="/dashboard")
        except HTTPException:
            # Token is invalid, proceed to render login page
            return templates.TemplateResponse("login.html", {"request": request, "error": error, "pageheader": PAGE_HEADER, "pagefooter": PAGE_FOOTER})

    return templates.TemplateResponse("login.html", {"request": request, "error": error,  "pageheader": PAGE_HEADER, "pagefooter": PAGE_FOOTER})

# Login / Logout / Authorization Handler (IF AUTHORIZED will RE-DIRECT TO AUTHORIZED API ENDPOINT)
@app.post("/login", response_class=HTMLResponse)
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    
    #auth_result = authenticate(username, password) #authenticate using LDAP3
    #auth_result = authenticate_netmiko(username, password) #authenticate using NETMIKO
    auth_result = authenticate_dummy(username, password) #authenticate using Dummy User
    #auth_result = authenticate_Xuser(username, password) # use sqlite 

    if auth_result is True:
        return handle_authenticated_response(username, password)
    else:
        return handle_error_response(auth_result)


@app.get("/logout")
async def logout(request: Request):
    response = RedirectResponse(url="/")
    response.delete_cookie("access_token")  # Clear JWT cookie
    return response

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    if exc.status_code == status.HTTP_401_UNAUTHORIZED:
        # Redirect to login page if not authenticated
        return RedirectResponse(url="/?error=you got expired.", status_code=303)
    return templates.TemplateResponse("welcome.html", {"request": request, "error": str(exc.detail)})

#######################################################################


# AUTHORIZED API ENDPOINT TO ACCESS
def render_page(route: str, template_path: str):
    @app.get(route, response_class=HTMLResponse)
    async def page(request: Request, current_user: tuple = Depends(get_current_user)):
        username, password = current_user
        return templates.TemplateResponse(template_path, {
            "request": request,
            "username": username,
            "password": password,
            "pageheader": PAGE_HEADER,
            "pagefooter": PAGE_FOOTER
        })
    return page



render_page("/dashboard", "restricted/dashboard.html")
render_page("/itemlog", "restricted/index2.html")
render_page("/clock1", "restricted/clock1.html")
render_page("/clock2", "restricted/clock2.html")



# AUTHORIZED API ENDPOINT TO ACCESS
@app.get("/clock22", response_class=HTMLResponse)
async def dashboard(request: Request, current_user: tuple = Depends(get_current_user)):
    username, password = current_user
    return templates.TemplateResponse("restricted/clock2.html", {
        "request": request, 
        "username": username, 
        "password": password,
        "pageheader": PAGE_HEADER, 
        "pagefooter": PAGE_FOOTER
        })




#######################################################################







if __name__ == "__main__":
    # Get port from command-line argument or use default 8857
   # port = int(sys.argv[1]) if len(sys.argv) > 1 else 8857

    cert_dir = os.path.join(os.path.dirname(__file__), "certs")
    ssl_keyfile = os.path.join(cert_dir, "server_unencrypted.key")
    ssl_certfile = os.path.join(cert_dir, "server.crt")

    #uvicorn.run(app, host="0.0.0.0", port=port, ssl_keyfile=ssl_keyfile, ssl_certfile=ssl_certfile)
    uvicorn.run(app, host="0.0.0.0", port=8856, ssl_keyfile=ssl_keyfile, ssl_certfile=ssl_certfile)