import { Client } from "https://cdn.skypack.dev/ldapts";

const url = "ldap://your-ldap-server.com";
const baseDN = "dc=example,dc=com"; // Base DN for your LDAP server

const adminBindDN = "cn=admin,dc=example,dc=com"; // Admin user DN
const adminPassword = "your-admin-password"; // Admin password

const client = new Client({ url });

async function main() {
  // Get username and password from the CLI
  const username = prompt("Enter username:");
  const password = prompt("Enter password:");

  if (!username || !password) {
    console.error("Both username and password are required!");
    return;
  }

  try {
    // Bind as admin to search for the user
    await client.bind(adminBindDN, adminPassword);

    // Search for the user
    const { searchEntries } = await client.search(baseDN, {
      filter: `(uid=${username})`,
      scope: "sub",
    });

    if (searchEntries.length === 0) {
      console.error("User not found.");
      return;
    }

    console.log("User found:", searchEntries[0]);

    // Try to bind as the user to validate the credentials
    const userDN = searchEntries[0].dn; // User's DN
    await client.bind(userDN, password);

    console.log("Authentication successful!");
  } catch (err) {
    console.error("Authentication failed:", err.message);
  } finally {
    // Unbind when done
    await client.unbind();
  }
}

main().catch((err) => console.error("Unexpected error:", err));
