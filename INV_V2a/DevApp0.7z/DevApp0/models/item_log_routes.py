from fastapi import APIRouter, Request
from pydantic import BaseModel
import sqlite3
from fastapi.templating import Jinja2Templates
import os
from datetime import datetime

router = APIRouter()
templates = Jinja2Templates(directory="templates")
DB_FILE = os.getenv("DB_FILE", "db/DAassets.db")
#DB_FILE = os.getenv("DB_FILE", "db/appFeb10.db")

def format_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

class ItemLog(BaseModel):
    refnum: str
    program_id: int
    item_id: int
    quantity: int
    location: str
    reason: str
    attendee: str

@router.get("/items-log")
async def items_log(request: Request):
    return templates.TemplateResponse("index2d.html", {"request": request})

@router.get("/entryAPI/items-log")
def get_items_log():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
    ''')
    
    items = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return items

@router.post("/entryAPI/items-log")
def add_item_log(item_log: ItemLog):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    timestamp = format_timestamp()
    cursor.execute(
        "INSERT INTO items_log (refnum, program_id, item_id, quantity, location, reason, timestamp, attendee) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (item_log.refnum, item_log.program_id, item_log.item_id, item_log.quantity, item_log.location, item_log.reason, timestamp, item_log.attendee)
    )
    conn.commit()
    conn.close()
    return {"message": "Item logged"}

@router.get("/entryAPI/items-log/{id}")
def get_item_log(id: int):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
        WHERE il.id = ?
    ''', (id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return dict(row)
    else:
        return {"error": "Item not found"}

@router.put("/entryAPI/items-log/{id}")
def update_item_log(id: int, item_log: ItemLog):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    timestamp = format_timestamp()
    cursor.execute(
        "UPDATE items_log SET refnum = ?, program_id = ?, item_id = ?, quantity = ?, location = ?, reason = ?, timestamp = ?, attendee = ? WHERE id = ?",
        (item_log.refnum, item_log.program_id, item_log.item_id, item_log.quantity, item_log.location, item_log.reason, timestamp, item_log.attendee, id)
    )
    conn.commit()
    conn.close()
    return {"message": "Item updated"}

@router.delete("/entryAPI/items-log/{id}")
def delete_item_log(id: int):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM items_log WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return {"message": "Item deleted"}