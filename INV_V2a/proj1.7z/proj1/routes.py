from fastapi import APIRouter, HTTPException
import sqlite3
from pydantic import BaseModel
from datetime import datetime
from typing import List

router = APIRouter()

db_path = "appFeb10.db"

def format_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Search request model
class ItemLogSearchRequest(BaseModel):
    search_term: str

# Item Log model
class ItemLog(BaseModel):
    refnum: str
    program_id: int
    item_id: int
    quantity: int
    location: str
    reason: str
    attendee: str

# Get programs
@router.get("/entryAPI/programs")
def get_programs():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT program_id, program_name FROM programs WHERE status = 'active'")
    programs = [{"program_id": row[0], "program_name": row[1]} for row in cursor.fetchall()]
    conn.close()
    return programs

# Get items
@router.get("/entryAPI/items")
def get_items():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM items")
    items = [{"item_id": row[0], "item_name": row[1]} for row in cursor.fetchall()]
    conn.close()
    return items


# Get all items log
@router.get("/entryAPI/items-log")
def get_items_log():
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
    ''')
    
    items = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return items

# Add an item log
@router.post("/entryAPI/items-log")
def add_item_log(item_log: ItemLog):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    timestamp = format_timestamp()
    cursor.execute(
        "INSERT INTO items_log (refnum, program_id, item_id, quantity, location, reason, timestamp, attendee) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (item_log.refnum, item_log.program_id, item_log.item_id, item_log.quantity, item_log.location, item_log.reason, timestamp, item_log.attendee)
    )
    conn.commit()
    conn.close()
    return {"message": "Item logged"}

# Update an item log
@router.put("/entryAPI/items-log/{id}")
def update_item_log(id: int, item_log: ItemLog):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    timestamp = format_timestamp()
    cursor.execute(
        "UPDATE items_log SET refnum = ?, program_id = ?, item_id = ?, quantity = ?, location = ?, reason = ?, timestamp = ?, attendee = ? WHERE id = ?",
        (item_log.refnum, item_log.program_id, item_log.item_id, item_log.quantity, item_log.location, item_log.reason, timestamp, item_log.attendee, id)
    )
    conn.commit()
    conn.close()
    return {"message": "Item updated"}

# Delete an item log
@router.delete("/entryAPI/items-log/{id}")
def delete_item_log(id: int):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM items_log WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return {"message": "Item deleted"}

# SEARCH and SELECT endpoint API
@router.post("/entryAPI/items-log-search", response_model=List[dict])
def search_items_log(request: ItemLogSearchRequest):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    search_query = f"""
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
        WHERE 
            p.program_name LIKE ? OR 
            i.item_name LIKE ? OR 
            il.quantity LIKE ? OR 
            il.location LIKE ? OR 
            il.reason LIKE ?
    """
    search_value = f"%{request.search_term}%"
    cursor.execute(search_query, (search_value, search_value, search_value, search_value, search_value))
    
    item_search = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return item_search

# LOAD SELECTED endpoint API for EDIT/UPDATE
@router.get("/entryAPI/items-log/{id}")
def get_item_log(id: int):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # Enables dictionary-like access to columns
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
        WHERE il.id = ?
    ''', (id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return dict(row)  # Converts the single row into a dictionary
    else:
        raise HTTPException(status_code=404, detail="Item not found")
