from fastapi import FastAPI, HTTPException, Request 

from fastapi.responses import FileResponse
import sqlite3
from pydantic import BaseModel
from datetime import datetime
import os
from typing import List

from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates


from dotenv import load_dotenv

app = FastAPI()

# Mount static files
app.mount("/static", StaticFiles(directory="static"))

# Initialize templates
templates = Jinja2Templates(directory="templates")


DB_FILE = os.getenv("DB_FILE", "db/appFeb10.db") 

##################################################################
# Run the database initialization
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS programs (
        program_id INTEGER PRIMARY KEY AUTOINCREMENT,
        program_name TEXT NOT NULL UNIQUE,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive'))
    );
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS items (
        item_id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_name TEXT NOT NULL UNIQUE
    );
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS items_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        refnum TEXT NOT NULL,
        program_id INTEGER NOT NULL,
        item_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        location TEXT NOT NULL,
        reason TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        attendee TEXT NOT NULL,
        FOREIGN KEY (program_id) REFERENCES programs(program_id),
        FOREIGN KEY (item_id) REFERENCES items(item_id)
    );
    ''')
    
    conn.commit()
    conn.close()

init_db()

def format_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

##########################   ITEM LOG ISSUANCE   ########################################
@app.get("/entryAPI/programs")
def get_programs():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT program_id, program_name FROM programs WHERE status = 'active'")
    programs = [{"program_id": row[0], "program_name": row[1]} for row in cursor.fetchall()]
    conn.close()
    return programs

@app.get("/entryAPI/items")
def get_items():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM items")
    items = [{"item_id": row[0], "item_name": row[1]} for row in cursor.fetchall()]
    conn.close()
    return items

# items-log API ====================================
class ItemLog(BaseModel):
    refnum: str
    program_id: int
    item_id: int
    quantity: int
    location: str
    reason: str
    attendee: str

# INITIALIZE Main Page - Select ALL Records and load to TABLE
@app.get("/items-log")
async def items_log(request: Request):
    return templates.TemplateResponse("index2d.html", {"request": request})
    #return templates.TemplateResponse("sidebar2.html", {"request": request})

# LOAD ALL Data to Table
@app.get("/entryAPI/items-log")
def get_items_log():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row  # Enables dictionary-like access to columns
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
    ''')
    
    items = [dict(row) for row in cursor.fetchall()]  # Converts each row to a dictionary
    conn.close()
    
    return items
   
# SAVE endpoint API
@app.post("/entryAPI/items-log")
def add_item_log(item_log: ItemLog):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    timestamp = format_timestamp()
    cursor.execute(
        "INSERT INTO items_log (refnum, program_id, item_id, quantity, location, reason, timestamp, attendee) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (item_log.refnum, item_log.program_id, item_log.item_id, item_log.quantity, item_log.location, item_log.reason, timestamp, item_log.attendee)
    )
    conn.commit()
    conn.close()
    return {"message": "Item logged"}


# LOAD SELECTED endpoint API for EDIT/UPDATE ==============
@app.get("/entryAPI/items-log/{id}")
def get_item_log(id: int):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row  # Enables dictionary-like access to columns
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
        WHERE il.id = ?
    ''', (id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return dict(row)  # Converts the single row into a dictionary
    else:
        return {"error": "Item not found"}

# UPDATE endpoint API
@app.put("/entryAPI/items-log/{id}")
def update_item_log(id: int, item_log: ItemLog):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    timestamp = format_timestamp()
    cursor.execute(
        "UPDATE items_log SET refnum = ?, program_id = ?, item_id = ?, quantity = ?, location = ?, reason = ?, timestamp = ?, attendee = ? WHERE id = ?",
        (item_log.refnum, item_log.program_id, item_log.item_id, item_log.quantity, item_log.location, item_log.reason, timestamp, item_log.attendee, id)
    )
    conn.commit()
    conn.close()
    return {"message": "Item updated"}

# DELETE endpoint API
@app.delete("/entryAPI/items-log/{id}")
def delete_item_log(id: int):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM items_log WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return {"message": "Item deleted"}


########################## items-log API SEARCH ##########################
class ItemLogSearchRequest(BaseModel):
    search_term: str  # The term to search across multiple fields

# SEARCH and SELECT endpoint API ==============
@app.post("/entryAPI/items-log-search", response_model=List[dict])
def search_items_log(request: ItemLogSearchRequest):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    search_query = f"""
        SELECT 
            il.id, il.refnum, p.program_name, i.item_name, il.quantity, il.location, 
            il.reason, il.timestamp, il.attendee, 
            il.program_id, il.item_id
        FROM items_log il
        JOIN programs p ON il.program_id = p.program_id
        JOIN items i ON il.item_id = i.item_id
        WHERE 
            p.program_name LIKE ? OR 
            i.item_name LIKE ? OR 
            il.quantity LIKE ? OR 
            il.location LIKE ? OR 
            il.reason LIKE ?
    """
    search_value = f"%{request.search_term}%"
    cursor.execute(search_query, (search_value, search_value, search_value, search_value, search_value))
    
    item_search = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return item_search

##########################   ITEM LOG ISSUANCE   #######################################






# [Rest of your existing code including the SSL configuration and main block]

cert_dir = os.path.join(os.path.dirname(__file__), "certs")
ssl_keyfile = os.path.join(cert_dir, "server_unencrypted.key")
ssl_certfile = os.path.join(cert_dir, "server.crt")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8851, ssl_keyfile=ssl_keyfile, ssl_certfile=ssl_certfile)




# Run the server using: uvicorn filename:app --reload
# uvicorn main_jwt:app --host 0.0.0.0.0 --port 8851 --reload --ssl-keyfile=certs/server_unencrypted.key --ssl-certfile=certs/server.crt


# uvicorn server3:app --host 0.0.0.0.0 --port 8821 --reload --ssl-keyfile=certs/server_unencrypted.key --ssl-certfile=certs/server.crt
# https://127.0.0.1:8821/items-log 