# main.py
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
from routes.item_routes import router as item_router

app = FastAPI()

# Mount static files
app.mount("/static", StaticFiles(directory="static"))

# Initialize templates
templates = Jinja2Templates(directory="templates")

# Include API routers with prefix
app.include_router(item_router, prefix="/entryAPI", tags=["items"])

# Main view route
@app.get("/items-log")
async def items_log(request: Request):
    return templates.TemplateResponse("index2d.html", {"request": request})

# SSL Configuration
cert_dir = os.path.join(os.path.dirname(__file__), "certs")
ssl_keyfile = os.path.join(cert_dir, "server_unencrypted.key")
ssl_certfile = os.path.join(cert_dir, "server.crt")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8851, ssl_keyfile=ssl_keyfile, ssl_certfile=ssl_certfile)