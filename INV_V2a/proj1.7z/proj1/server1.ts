import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { DB } from "https://deno.land/x/sqlite/mod.ts";

// Initialize SQLite database
const db = new DB("app.db");

// Drop existing table if it exists (for clean migration)
db.query(`DROP TABLE IF EXISTS items_log`);

// Create a modified table with new fields
db.query(`
  CREATE TABLE IF NOT EXISTS items_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    refnum TEXT NOT NULL,
    program TEXT NOT NULL,
    items TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    location TEXT NOT NULL,
    reason TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    attendedby TEXT NOT NULL
  );
`);

async function parseJSON(req: Request): Promise<any> {
  const text = await req.text();
  return JSON.parse(text || "{}");
}

async function handler(req: Request): Promise<Response> {
  const url = new URL(req.url);
  
  if (url.pathname === "/" && req.method === "GET") {
    const file = await Deno.readFile("./public/index.html");
    return new Response(file, { headers: { "Content-Type": "text/html" } });
  }

  if (url.pathname === "/api/items" && req.method === "GET") {
    const items = [...db.query("SELECT * FROM items_log")].map(
      ([id, refnum, program, items, quantity, location, reason, timestamp, attendedby]) => ({
        id,
        refnum,
        program,
        items,
        quantity,
        location,
        reason,
        timestamp,
        attendedby
      })
    );
    return Response.json(items);
  }

  if (url.pathname === "/api/items" && req.method === "POST") {
    const { refnum, program, items, quantity, location, reason, attendedby } = await parseJSON(req);
    const timestamp = new Date().toISOString();
    
    db.query(
      "INSERT INTO items_log (refnum, program, items, quantity, location, reason, timestamp, attendedby) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      [refnum, program, items, quantity, location, reason, timestamp, attendedby]
    );
    return new Response("Item logged", { status: 201 });
  }

  if (url.pathname.startsWith("/api/items/") && req.method === "PUT") {
    const id = parseInt(url.pathname.split("/").pop() || "");
    const { refnum, program, items, quantity, location, reason, attendedby } = await parseJSON(req);
    const timestamp = new Date().toISOString(); // Update timestamp on edit
    
    db.query(
      "UPDATE items_log SET refnum = ?, program = ?, items = ?, quantity = ?, location = ?, reason = ?, timestamp = ?, attendedby = ? WHERE id = ?",
      [refnum, program, items, quantity, location, reason, timestamp, attendedby, id]
    );
    return new Response("Item updated", { status: 200 });
  }

  if (url.pathname.startsWith("/api/items/") && req.method === "DELETE") {
    const id = parseInt(url.pathname.split("/").pop() || "");
    db.query("DELETE FROM items_log WHERE id = ?", [id]);
    return new Response("Item deleted", { status: 200 });
  }

  return new Response("Not Found", { status: 404 });
}

console.log("Server running on http://localhost:8000");
serve(handler, { port: 8000 });