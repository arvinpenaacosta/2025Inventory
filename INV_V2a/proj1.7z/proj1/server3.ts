import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { DB } from "https://deno.land/x/sqlite/mod.ts";

// Initialize SQLite database
const db = new DB("app.db");

// Create tables if they don't exist
db.query(`
  CREATE TABLE IF NOT EXISTS programs (
    program_id INTEGER PRIMARY KEY AUTOINCREMENT,
    program_name TEXT NOT NULL UNIQUE,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive'))
  );
`);

async function parseJSON(req: Request): Promise<any> {
  const text = await req.text();
  return JSON.parse(text || "{}");
}

async function handler(req: Request): Promise<Response> {
  const url = new URL(req.url);

  // Serve the main HTML file
  if (url.pathname === "/apifm_program" && req.method === "GET") {
    const file = await Deno.readFile("./public/index3.html");
    return new Response(file, { headers: { "Content-Type": "text/html" } });
  }

  // Get all programs
  if (url.pathname === "/apifm/programs" && req.method === "GET") {
    const programs = [...db.query("SELECT * FROM programs")].map(
      ([program_id, program_name, status]) => ({ program_id, program_name, status })
    );
    return Response.json(programs);
  }

  // Add new program
  if (url.pathname === "/apifm/programs" && req.method === "POST") {
    const { program_name, status } = await parseJSON(req);
    db.query(
      "INSERT INTO programs (program_name, status) VALUES (?, ?)",
      [program_name, status]
    );
    return new Response("Program added", { status: 201 });
  }

  // Update program
  if (url.pathname.startsWith("/apifm/programs/") && req.method === "PUT") {
    const id = parseInt(url.pathname.split("/").pop() || "");
    const { program_name, status } = await parseJSON(req);
    db.query(
      "UPDATE programs SET program_name = ?, status = ? WHERE program_id = ?",
      [program_name, status, id]
    );
    return new Response("Program updated", { status: 200 });
  }

  // Delete program
  if (url.pathname.startsWith("/apifm/programs/") && req.method === "DELETE") {
    const id = parseInt(url.pathname.split("/").pop() || "");
    db.query("DELETE FROM programs WHERE program_id = ?", [id]);
    return new Response("Program deleted", { status: 200 });
  }

  return new Response("Not Found", { status: 404 });
}

console.log("Server running on http://localhost:8000");
serve(handler, { port: 8000 });
