from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
import sqlite3
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv
import os

from models.item_log_routes import router as item_log_router  # Import the router

app = FastAPI()

# Mount static files
app.mount("/static", StaticFiles(directory="static"))

# Initialize templates
templates = Jinja2Templates(directory="templates")

DB_FILE = os.getenv("DB_FILE", "db/appFeb10.db")

##################################################################
# Run the database initialization
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS programs (
        program_id INTEGER PRIMARY KEY AUTOINCREMENT,
        program_name TEXT NOT NULL UNIQUE,
        status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive'))
    );
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS items (
        item_id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_name TEXT NOT NULL UNIQUE
    );
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS items_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        refnum TEXT NOT NULL,
        program_id INTEGER NOT NULL,
        item_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        location TEXT NOT NULL,
        reason TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        attendee TEXT NOT NULL,
        FOREIGN KEY (program_id) REFERENCES programs(program_id),
        FOREIGN KEY (item_id) REFERENCES items(item_id)
    );
    ''')
    
    conn.commit()
    conn.close()

init_db()

@app.get("/entryAPI/programs")
def get_programs():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT program_id, program_name FROM programs WHERE status = 'active'")
    programs = [{"program_id": row[0], "program_name": row[1]} for row in cursor.fetchall()]
    conn.close()
    return programs

@app.get("/entryAPI/items")
def get_items():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM items")
    items = [{"item_id": row[0], "item_name": row[1]} for row in cursor.fetchall()]
    conn.close()
    return items

# Include the item log routes
app.include_router(item_log_router)

cert_dir = os.path.join(os.path.dirname(__file__), "certs")
ssl_keyfile = os.path.join(cert_dir, "server_unencrypted.key")
ssl_certfile = os.path.join(cert_dir, "server.crt")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8851, ssl_keyfile=ssl_keyfile, ssl_certfile=ssl_certfile)



#
#
#your_project/
#├── main.py
#├── item_log_routes.py
#├── templates/
#│   └── index2d.html
#├── static/
#└── certs/
#    ├── server_unencrypted.key
#    └── server.crt
#




