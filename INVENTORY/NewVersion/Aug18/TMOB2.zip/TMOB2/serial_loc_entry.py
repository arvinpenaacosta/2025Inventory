import sys
import json
import os
import ast
import sqlite3
import time
from datetime import datetime
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QVBoxLayout, QComboBox, QPushButton,
    QLineEdit, QTableWidget, QTableWidgetItem, QHBoxLayout, QMessageBox,
    QMenuBar, QAction, QInputDialog
)
from PyQt5.QtGui import QFont, QBrush, QColor
from PyQt5.QtCore import Qt
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
json_file2 = os.getenv("JSON_FILE2", "devappData.json")
db_folder = os.getenv("FILE_PATH", ".")
db_name = os.getenv("FILE_SQLITE", "default_db")
reasonfor_values = ast.literal_eval(os.getenv("REASONFOR", "[]"))

def load_devapp_data():
    with open(json_file2, "r", encoding="utf-8") as f:
        return json.load(f)

# Aliases mapping for prettier display
field_aliases = {
    "log_user": "User",
    "hostname": "Hostname",
    "serial_number": "Serial Number",
    "processor": "Processor",
    "windows_version": "OS Version",
    "windows_display_version": "Display Version",
    "manufacturer": "Manufacturer",
    "model": "Model",
    "total_ram": "Total RAM",
    "num_ram_slots": "Number of RAM Slots",
    "ram_per_slot": "RAM per Slot",
    "ram_speed": "RAM Speed",
    "ram_type": "RAM Type",
    "ip_address": "IP Address",
    "mac_address": "MAC Address",
    "citrix_name": "Citrix Name",
    "citrix_version": "Citrix Version",
    "timestamp": "Timestamp",
    "floor": "Floor",
    "room": "Selections",
    "room_name": "Name",
    "D1": "Code",
    "E1": "Loc1",
    "E2": "Seat",
    "location_code": "Room Desc",
    "taskfor": "Task",
    "status": "Status"
}

class SerialLocationRecorder(QWidget):
    def __init__(self):
        super().__init__()

        # Get user name at startup
        self.log_user = self.get_user_name()
        if not self.log_user:
            # User cancelled, exit application
            sys.exit()

        self.setGeometry(100, 100, 300, 400) 
        self.setWindowTitle("ePx - Pull-out Asset Recorder")
        self.setFixedSize(300, 400)  # Initial compact size

        self.devappData = load_devapp_data()
        app_font = QFont("Segoe UI", 12)
        self.setFont(app_font)

        self.floor_data = None
        self.room_data = None
        self.answers = {}
        self.combined_data = None

        # Create menu bar
        self.menu_bar = QMenuBar(self)
        help_menu = self.menu_bar.addMenu("Help")
        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about_dialog)
        help_menu.addAction(about_action)

        self.layout = QVBoxLayout()
        self.layout.setAlignment(Qt.AlignTop)
        self.layout.setMenuBar(self.menu_bar)

        # Serial Number Input
        self.serial_label = QLabel("Enter Serial Number")
        self.serial_input = QLineEdit()
        self.serial_input.setPlaceholderText("Enter serial number")

        # Dropdowns
        self.floor_label = QLabel("Select Destination Floor")
        self.floor_combo = QComboBox()
        self.floor_combo.addItem("-- Choose Floor --")
        for floor in self.devappData:
            self.floor_combo.addItem(floor["floor"])
        self.floor_combo.currentIndexChanged.connect(self.on_floor_change)

        self.room_label = QLabel("Storing Device to")
        self.room_combo = QComboBox()
        self.room_combo.addItem("-- Choose Room Type --")
        self.room_combo.currentIndexChanged.connect(self.on_room_change)
        self.room_combo.hide()
        self.room_label.hide()

        self.l1_label = QLabel()
        self.l1_combo = QComboBox()
        self.l1_combo.currentIndexChanged.connect(self.on_l1_change)
        self.l1_combo.hide()
        self.l1_label.hide()

        self.e1_label = QLabel()
        self.e1_combo = QComboBox()
        self.e1_combo.currentIndexChanged.connect(self.on_e1_change)
        self.e1_combo.hide()
        self.e1_label.hide()

        self.e2_label = QLabel()
        self.e2_combo = QComboBox()
        self.e2_combo.currentIndexChanged.connect(self.on_e2_change)
        self.e2_combo.hide()
        self.e2_label.hide()

        self.status_label = QLabel("Select Status")
        self.status_combo = QComboBox()
        for reason in reasonfor_values:
            self.status_combo.addItem(reason)
        self.status_combo.currentIndexChanged.connect(self.on_status_change)
        self.status_combo.hide()
        self.status_label.hide()
        
        # Set default status value if reasonfor_values exists
        if reasonfor_values:
            self.answers["status"] = reasonfor_values[0]

        # Submit Button
        self.submit_btn = QPushButton("Submit")
        self.submit_btn.clicked.connect(self.on_submit)
        self.submit_btn.hide()

        # Summary Table (moved size expansion here)
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Field", "Value"])
        self.table.setColumnWidth(0, 200)
        self.table.setColumnWidth(1, 400)
        self.table.hide()

        # Back and Save Buttons
        self.button_layout = QHBoxLayout()
        self.back_button = QPushButton("Back")
        self.back_button.setMinimumSize(120, 45)
        self.back_button.setStyleSheet("""
            QPushButton {
                background-color: #6c757d;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #5a6268;
            }
            QPushButton:pressed {
                background-color: #545b62;
            }
        """)
        self.back_button.clicked.connect(self.go_back)
        self.back_button.hide()

        self.save_button = QPushButton("Save")
        self.save_button.setMinimumSize(120, 45)
        self.save_button.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 14px;
                font-weight: bold;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #218838;
            }
            QPushButton:pressed {
                background-color: #1e7e34;
            }
        """)
        self.save_button.clicked.connect(self.save_data_to_db)
        self.save_button.hide()

        self.button_layout.addWidget(self.back_button)
        self.button_layout.addWidget(self.save_button)

        # Add widgets to layout
        self.layout.addWidget(self.serial_label)
        self.layout.addWidget(self.serial_input)
        self.layout.addWidget(self.floor_label)
        self.layout.addWidget(self.floor_combo)
        self.layout.addWidget(self.room_label)
        self.layout.addWidget(self.room_combo)
        self.layout.addWidget(self.l1_label)
        self.layout.addWidget(self.l1_combo)
        self.layout.addWidget(self.e1_label)
        self.layout.addWidget(self.e1_combo)
        self.layout.addWidget(self.e2_label)
        self.layout.addWidget(self.e2_combo)
        self.layout.addWidget(self.status_label)
        self.layout.addWidget(self.status_combo)
        self.layout.addWidget(self.submit_btn)
        self.layout.addWidget(self.table)
        self.layout.addLayout(self.button_layout)

        self.setLayout(self.layout)

    def get_user_name(self):
        """Get user name at application startup"""
        # Create a custom input dialog with larger font
        dialog = QInputDialog()
        dialog.setWindowTitle('User Login')
        dialog.setLabelText('Enter your name:')
        dialog.setTextValue('')
        
        # Set larger font for the input field
        font = QFont("Segoe UI", 16)  # Larger font size
        dialog.setFont(font)
        
        ok = dialog.exec_()
        name = dialog.textValue()
        
        if ok and name.strip():
            return name.strip()
        else:
            # User cancelled or entered empty name
            QMessageBox.information(None, "Application Exit", "Name is required to proceed.")
            return None

    def show_about_dialog(self):
        about_message = """
        ePx Inventory Serial Recorder
        Version: 1.0.0

        This application is designed to update desktop computer inventory records by searching for existing records using a serial number and adding new location and status information.

        Features:
        - Search for the latest inventory record by serial number in a SQLite database.
        - Input new location details (floor, room, etc.) using cascading dropdowns.
        - Select a status from predefined reasons (e.g., Faulty, For Checking, For Repair).
        - Display combined data in a summary table with formatted fields.
        - Save a new record to the inventory database with task set to 'Pull Out'.

        Developed by: Arvin Acosta
        System Engineer, IT NOC, ePerformax © 2025
        """
        QMessageBox.about(self, "ePx Inventory Serial Recorder", about_message)

    def on_floor_change(self, index):
        self.room_combo.clear()
        self.room_combo.addItem("-- Choose Room Type --")
        self.room_combo.hide()
        self.room_label.hide()
        self.l1_combo.hide()
        self.l1_label.hide()
        self.e1_combo.hide()
        self.e1_label.hide()
        self.e2_combo.hide()
        self.e2_label.hide()
        self.status_combo.hide()
        self.status_label.hide()
        self.submit_btn.hide()
        self.table.hide()
        self.back_button.hide()
        self.save_button.hide()

        if index == 0:
            self.floor_data = None
            return

        self.floor_data = self.devappData[index - 1]
        for room in self.floor_data["rooms"]:
            key = list(room["CO"].keys())[0]
            name = room["CO"][key]
            self.room_combo.addItem(f"{key} - {name}", userData=key)
        self.room_combo.show()
        self.room_label.show()

        self.answers["floor"] = self.floor_data["floor"]

    def on_room_change(self, index):
        self.l1_combo.hide()
        self.l1_label.hide()
        self.e1_combo.hide()
        self.e1_label.hide()
        self.e2_combo.hide()
        self.e2_label.hide()
        self.status_combo.hide()
        self.status_label.hide()
        self.submit_btn.hide()
        self.table.hide()
        self.back_button.hide()
        self.save_button.hide()

        if index == 0 or self.floor_data is None:
            self.room_data = None
            return

        key = self.room_combo.itemData(index)
        self.room_data = next((r for r in self.floor_data["rooms"] if key in r["CO"]), None)

        if self.room_data is None:
            return

        self.answers["room"] = key
        self.answers["room_name"] = self.room_data["CO"][key]
        self.answers["D1"] = self.room_data["D1"]

        if "L1" in self.room_data and self.room_data["L1"]:
            self.l1_label.setText(self.room_data["L1"])
            self.populate_combo(self.l1_combo, self.room_data["E1"]["Range"])
            self.l1_label.show()
            self.l1_combo.show()
        else:
            self.show_e1()

    def on_l1_change(self, index):
        if index == 0:
            return
        self.answers["L1"] = self.l1_combo.currentText()

        self.e2_label.setText(self.room_data["E2"]["label"])
        self.populate_combo(self.e2_combo, self.room_data["E2"]["Range"])
        self.e2_label.show()
        self.e2_combo.show()

    def populate_combo(self, combo, range_data):
        combo.clear()
        combo.addItem("-- Choose --")
        if isinstance(range_data, dict):
            for val in range_data.values():
                combo.addItem(str(val))
        else:
            for val in range_data:
                combo.addItem(str(val))

    def show_e1(self):
        if self.room_data is None:
            return

        self.e1_label.setText(self.room_data["E1"]["label"])
        self.populate_combo(self.e1_combo, self.room_data["E1"]["Range"])
        self.e1_label.show()
        self.e1_combo.show()

    def on_e1_change(self, index):
        if index == 0 or self.room_data is None:
            return
        self.answers["E1"] = self.e1_combo.currentText()

        self.e2_label.setText(self.room_data["E2"]["label"])
        self.populate_combo(self.e2_combo, self.room_data["E2"]["Range"])
        self.e2_label.show()
        self.e2_combo.show()

    def on_e2_change(self, index):
        if index == 0:
            return
        self.answers["E2"] = self.e2_combo.currentText()
        self.status_label.show()
        self.status_combo.show()
        self.submit_btn.show()

    def on_status_change(self, index):
        if reasonfor_values and index >= 0 and index < len(reasonfor_values):
            self.answers["status"] = reasonfor_values[index]

    def generate_location_code(self):
        code_parts = []
        if "floor" in self.answers:
            code_parts.append(self.answers["floor"])
        if "D1" in self.answers:
            code_parts.append(self.answers["D1"])
        if "E1" in self.answers:
            e1_value = self.answers["E1"]
            try:
                e1_num = int(e1_value)
                if 0 < e1_num < 10:
                    code_parts.append(f"{e1_num:02d}")
                else:
                    code_parts.append(str(e1_value))
            except ValueError:
                code_parts.append(str(e1_value))
        if "E2" in self.answers:
            e2_value = self.answers["E2"]
            try:
                e2_num = int(e2_value)
                if 0 < e2_num < 10:
                    code_parts.append(f"{e2_num:02d}")
                else:
                    code_parts.append(str(e2_value))
            except ValueError:
                code_parts.append(str(e2_value))
        return "_".join(code_parts)

    def search_database(self, serial_number):
        db_path = os.path.join(db_folder, f"{db_name}.db")
        try:
            conn = sqlite3.connect(db_path)
            cur = conn.cursor()
            cur.execute("""
                SELECT * FROM inventory WHERE serial_number = ? ORDER BY timestamp DESC LIMIT 1
            """, (serial_number,))
            record = cur.fetchone()
            conn.close()
            if record:
                columns = [
                    "id", "floor", "roomname", "loc1", "loc2", "loceam", "log_user", "hostname",
                    "serial_number", "processor", "windows_version", "windows_display_version",
                    "manufacturer", "model", "total_ram", "num_ram_slots", "ram_per_slot",
                    "ram_speed", "ram_type", "ip_address", "mac_address", "citrix_name",
                    "citrix_version", "timestamp", "taskfor", "status"
                ]
                return dict(zip(columns, record))
            return {}
        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Failed to search database: {str(e)}")
            return {}

    def populate_table(self, data):
        # Define the exact order for display
        display_order = [
            "status", "taskfor", "hostname", "serial_number", "floor", "room", "room_name", 
            "D1", "E1", "E2", "location_code", "processor", "windows_version", 
            "windows_display_version", "manufacturer", "model", "total_ram", 
            "num_ram_slots", "ram_per_slot", "ram_speed", "ram_type", "ip_address", 
            "mac_address", "citrix_name", "citrix_version", "timestamp", "log_user"
        ]
        
        all_data = [(key, data.get(key)) for key in display_order if data.get(key) is not None]
        self.table.setRowCount(len(all_data))
        for row, (key, value) in enumerate(all_data):
            display_name = field_aliases.get(key, key)
            if key in ["E1", "E2"]:
                try:
                    num_value = int(value)
                    if 0 < num_value < 10:
                        display_value = f"{num_value:02d}"
                    else:
                        display_value = str(value)
                except (ValueError, TypeError):
                    display_value = str(value) if value is not None else ""
            else:
                display_value = str(value) if value is not None else ""

            name_item = QTableWidgetItem(display_name)
            value_item = QTableWidgetItem(display_value)

            if key in ["taskfor", "status", "hostname"]:
                bold_font = QFont()
                bold_font.setBold(True)
                name_item.setFont(bold_font)
                name_item.setForeground(QBrush(QColor("blue")))
                value_item.setFont(bold_font)
                value_item.setForeground(QBrush(QColor("blue")))

            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, value_item)

    def on_submit(self):
        serial_number = self.serial_input.text().strip()
        if not serial_number:
            QMessageBox.warning(self, "Invalid Input", "Please enter a serial number.")
            return
        if not all(key in self.answers for key in ["floor", "room", "room_name", "D1", "E1", "E2"]):
            QMessageBox.warning(self, "Incomplete Selection", "Please complete all location selections.")
            return
        if "status" not in self.answers:
            QMessageBox.warning(self, "Incomplete Selection", "Please select a status.")
            return

        self.answers["location_code"] = self.generate_location_code()
        self.answers["taskfor"] = "Pull Out"
        self.answers["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        db_data = self.search_database(serial_number)
        if not db_data:
            QMessageBox.information(self, "No Record Found", "No record found for this serial number. Proceeding with location data only.")

        self.combined_data = {
            **{k: db_data.get(k) for k in [
                "hostname", "serial_number", "processor", "windows_version",
                "windows_display_version", "manufacturer", "model", "total_ram",
                "num_ram_slots", "ram_per_slot", "ram_speed", "ram_type", "ip_address",
                "mac_address", "citrix_name", "citrix_version"
            ]},
            "log_user": self.log_user,  # Use the name entered at startup
            **self.answers
        }

        # Hide input form
        self.serial_label.hide()
        self.serial_input.hide()
        self.floor_label.hide()
        self.floor_combo.hide()
        self.room_label.hide()
        self.room_combo.hide()
        self.l1_label.hide()
        self.l1_combo.hide()
        self.e1_label.hide()
        self.e1_combo.hide()
        self.e2_label.hide()
        self.e2_combo.hide()
        self.status_label.hide()
        self.status_combo.hide()
        self.submit_btn.hide()

        # Expand window size for summary table
        self.setFixedSize(500, 700)
        
        # Show summary table and buttons
        self.table.show()
        self.back_button.show()
        self.save_button.show()
        self.populate_table(self.combined_data)

    def go_back(self):
        self.table.clearContents()
        self.table.setRowCount(0)
        self.table.hide()
        self.back_button.hide()
        self.save_button.hide()

        # Restore original compact size
        self.setFixedSize(300, 400)

        self.serial_input.clear()
        self.serial_label.show()
        self.serial_input.show()
        self.floor_label.show()
        self.floor_combo.show()
        self.floor_combo.setCurrentIndex(0)
        self.answers = {}
        self.combined_data = None

    def save_data_to_db(self):
        if not self.combined_data:
            QMessageBox.critical(self, "Error", "No data to save.")
            return

        db_path = os.path.join(db_folder, f"{db_name}.db")
        try:
            conn = sqlite3.connect(db_path)
            cur = conn.cursor()

            cur.execute("""
                CREATE TABLE IF NOT EXISTS inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    floor TEXT,
                    roomname TEXT,
                    loc1 TEXT,
                    loc2 TEXT,
                    loceam TEXT,
                    log_user TEXT,
                    hostname TEXT,
                    serial_number TEXT,
                    processor TEXT,
                    windows_version TEXT,
                    windows_display_version TEXT,
                    manufacturer TEXT,
                    model TEXT,
                    total_ram TEXT,
                    num_ram_slots TEXT,
                    ram_per_slot TEXT,
                    ram_speed TEXT,
                    ram_type TEXT,
                    ip_address TEXT,
                    mac_address TEXT,
                    citrix_name TEXT,
                    citrix_version TEXT,
                    timestamp TEXT,
                    taskfor TEXT,
                    status TEXT
                );
            """)

            data = self.combined_data
            e1_value = data.get("E1")
            try:
                e1_num = int(e1_value)
                if 0 < e1_num < 10:
                    formatted_e1 = f"{e1_num:02d}"
                else:
                    formatted_e1 = str(e1_value)
            except (ValueError, TypeError):
                formatted_e1 = str(e1_value) if e1_value is not None else ""

            e2_value = data.get("E2")
            try:
                e2_num = int(e2_value)
                if 0 < e2_num < 10:
                    formatted_e2 = f"{e2_num:02d}"
                else:
                    formatted_e2 = str(e2_value)
            except (ValueError, TypeError):
                formatted_e2 = str(e2_value) if e2_value is not None else ""

            values = (
                data.get("floor"),
                data.get("room_name"),
                f"{data.get('D1', '')}{formatted_e1}",
                formatted_e2,
                None,
                self.log_user,  # Use the name entered at startup
                data.get("hostname"),
                data.get("serial_number"),
                data.get("processor"),
                data.get("windows_version"),
                data.get("windows_display_version"),
                data.get("manufacturer"),
                data.get("model"),
                data.get("total_ram"),
                data.get("num_ram_slots"),
                data.get("ram_per_slot"),
                data.get("ram_speed"),
                data.get("ram_type"),
                data.get("ip_address"),
                data.get("mac_address"),
                data.get("citrix_name"),
                data.get("citrix_version"),
                data.get("timestamp"),
                data.get("taskfor"),
                data.get("status")
            )

            cur.execute("""
                INSERT INTO inventory (
                    floor, roomname, loc1, loc2, loceam, log_user, hostname, serial_number,
                    processor, windows_version, windows_display_version, manufacturer, model,
                    total_ram, num_ram_slots, ram_per_slot, ram_speed, ram_type, ip_address,
                    mac_address, citrix_name, citrix_version, timestamp, taskfor, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, values)

            conn.commit()
            conn.close()

            QMessageBox.information(self, "Success", "Data saved to database.")
            QApplication.quit()

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Failed to save to database: {str(e)}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SerialLocationRecorder()
    window.show()
    sys.exit(app.exec_())