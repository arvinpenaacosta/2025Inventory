import json
import sqlite3
from tkinter import Tk, filedialog

# Hide the Tkinter root window
Tk().withdraw()

# Open file dialog to select JSON query file
json_file = filedialog.askopenfilename(
    title="Select JSON Query File",
    filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
)

if not json_file:
    print("No file selected.")
    exit()

# Load JSON queries
with open(json_file, "r", encoding="utf-8") as f:
    queries = json.load(f)

# List available query names
print("\nAvailable Queries:")
for name in queries["queries"]:
    print(f"- {name}")

# Ask user to choose one
selected_query = input("\nEnter query name: ").strip()

if selected_query not in queries["queries"]:
    print("Query not found in JSON.")
    exit()

query = queries["queries"][selected_query]["query"]

# Connect to SQLite database
db_file = filedialog.askopenfilename(
    title="Select SQLite Database",
    filetypes=[("SQLite DB", "*.db *.sqlite"), ("All files", "*.*")]
)

if not db_file:
    print("No database selected.")
    exit()

conn = sqlite3.connect(db_file)
cursor = conn.cursor()

# Execute the query
print("\nRunning query...")
cursor.execute(query)
rows = cursor.fetchall()

# Show results
print(f"\nReturned {len(rows)} rows:")
for row in rows:
    print(row)

conn.close()
