const queries = {
  queries: {
    "Latest Inventory": {
      html: "Link_1, [Latest Inventory]",
      jsfile: "DataIn_1",
    },
    "Inventory per Device": {
      html: "Link_2, [Latest Inventory2]",
      jsfile: "DataIn_2",
    },
    "Citrix Workspace 25.3.10.69": {
      html: "Link_3, [Latest Inventory3]",
      jsfile: "DataIn_3",
    },
    "(PROGRAM) Asset Total Count ": {
      html: "value1",
      jsfile: "DashValue1",
    },
    "Asset Count per Location (Loc1)": {
      html: "Graph_1",
      jsfile: "Graph_1",
     }
  }
};

