from netmiko import ConnectHandler
import re
import logging

# 📜 Setup logging
logging.basicConfig(filename='mac_lookup.log', level=logging.INFO, format='%(asctime)s - %(message)s')

# 🔧 Device Configuration
device = {
    'device_type': 'cisco_ios',
    'ip': '192.168.1.1',         # Replace with your switch IP
    'username': 'admin',         # Replace with your username
    'password': 'your_password', # Replace with your password
}

# 🧾 List of MAC addresses to search
mac_addresses = [
    '00:1A:2B:3C:4D:5E',
    '00:1B:2C:3D:4E:6F',
    '00:1C:2D:3E:4F:7A'
]

# Convert MAC to Cisco format (xxxx.xxxx.xxxx)
def format_mac(mac):
    mac = mac.lower().replace(":", "").replace("-", "")
    return f"{mac[0:4]}.{mac[4:8]}.{mac[8:12]}"

def lookup_mac(net_connect, mac):
    formatted_mac = format_mac(mac)
    result = {'mac': mac, 'formatted_mac': formatted_mac}

    try:
        # 🔍 Step 1: Find port from MAC
        mac_table_output = net_connect.send_command(f"show mac address-table | include {formatted_mac}")
        port_match = re.search(r'(\S+)\s+{0}\s+\S+\s+(\S+)'.format(re.escape(formatted_mac)), mac_table_output)
        if not port_match:
            result['error'] = 'MAC not found in MAC table'
            return result

        port = port_match.group(2)
        result['port'] = port

        # 🔍 Step 2: Find VLAN
        switchport_output = net_connect.send_command(f"show interface {port} switchport")
        vlan_match = re.search(r'Access Mode VLAN:\s+(\d+)', switchport_output)
        vlan = vlan_match.group(1) if vlan_match else "Unknown"
        result['vlan'] = vlan

        # 🌐 Step 3: Find IP from ARP
        arp_output = net_connect.send_command(f"show ip arp | include {formatted_mac}")
        ip_match = re.search(r'(\d+\.\d+\.\d+\.\d+)\s+\S+\s+{0}'.format(re.escape(formatted_mac)), arp_output)
        if ip_match:
            result['ip'] = ip_match.group(1)
        else:
            result['ip'] = 'Not found'

    except Exception as e:
        result['error'] = str(e)

    return result

def main():
    try:
        net_connect = ConnectHandler(**device)
        print(f"Connected to {device['ip']}\n")

        summary = []

        for mac in mac_addresses:
            print(f"🔍 Looking up MAC: {mac}")
            result = lookup_mac(net_connect, mac)

            if 'error' in result:
                print(f"❌ Error: {result['error']}")
                logging.error(f"{mac} - {result['error']}")
            else:
                print(f"✅ Port: {result['port']}, VLAN: {result['vlan']}, IP: {result['ip']}")
                logging.info(f"{mac} → Port: {result['port']}, VLAN: {result['vlan']}, IP: {result['ip']}")

            summary.append(result)
            print("-" * 50)

        net_connect.disconnect()

        # 📦 Summary
        print("\n📦 Lookup Summary:")
        for item in summary:
            line = f"{item['mac']} → Port: {item.get('port', 'N/A')}, VLAN: {item.get('vlan', 'N/A')}, IP: {item.get('ip', 'N/A')}"
            print(line)

    except Exception as e:
        print(f"❌ Connection failed: {e}")
        logging.error(f"Connection failed: {e}")

if __name__ == "__main__":
    main()